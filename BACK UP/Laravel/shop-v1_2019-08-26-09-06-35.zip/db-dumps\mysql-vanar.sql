
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES (1,'2019-08-26 12:16:46','2019-08-26 12:16:46',NULL),(2,'2019-08-26 12:16:46','2019-08-26 12:16:46',NULL),(3,'2019-08-26 12:16:46','2019-08-26 12:16:46',NULL);
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=184345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (267,NULL,'Books','2019-08-26 12:24:43','2019-08-26 12:24:43'),(550,NULL,'Art','2019-08-26 12:24:43','2019-08-26 12:24:43'),(552,550,'Art Drawings','2019-08-26 12:24:45','2019-08-26 12:24:45'),(625,NULL,'Cameras & Photo','2019-08-26 12:24:43','2019-08-26 12:24:43'),(1207,4707,'Other Architectural Antiques','2019-08-26 12:24:50','2019-08-26 12:24:50'),(1269,11748,'Other Agriculture & Forestry','2019-08-26 12:24:50','2019-08-26 12:24:50'),(2194,20082,'Other Asian Antiques','2019-08-26 12:24:51','2019-08-26 12:24:51'),(2211,550,'Art Photographs','2019-08-26 12:24:45','2019-08-26 12:24:45'),(2984,NULL,'Baby','2019-08-26 12:24:43','2019-08-26 12:24:43'),(2988,100223,'Playpens & Play Yards','2019-08-26 12:24:56','2019-08-26 12:24:56'),(2990,100223,'Baby Swings','2019-08-26 12:24:56','2019-08-26 12:24:56'),(4707,20081,'Architectural & Garden','2019-08-26 12:24:45','2019-08-26 12:24:45'),(4708,4707,'Garden','2019-08-26 12:24:50','2019-08-26 12:24:50'),(11724,625,'Camcorders','2019-08-26 12:24:47','2019-08-26 12:24:47'),(11748,12576,'Agriculture & Forestry','2019-08-26 12:24:46','2019-08-26 12:24:46'),(12576,NULL,'Business & Industrial','2019-08-26 12:24:43','2019-08-26 12:24:43'),(15200,625,'Camera & Photo Accessories','2019-08-26 12:24:47','2019-08-26 12:24:47'),(18871,15200,'Memory Cards','2019-08-26 12:24:51','2019-08-26 12:24:51'),(19069,100223,'Baby Gyms & Play Mats','2019-08-26 12:24:56','2019-08-26 12:24:56'),(20081,NULL,'Antiques','2019-08-26 12:24:43','2019-08-26 12:24:43'),(20082,20081,'Asian Antiques','2019-08-26 12:24:45','2019-08-26 12:24:45'),(20394,2984,'Bathing & Grooming','2019-08-26 12:24:46','2019-08-26 12:24:46'),(20398,20394,'Skin Care','2019-08-26 12:24:52','2019-08-26 12:24:52'),(20413,100223,'Activity Centers','2019-08-26 12:24:56','2019-08-26 12:24:56'),(20433,2984,'Baby Safety & Health','2019-08-26 12:24:46','2019-08-26 12:24:46'),(20435,20433,'Baby Monitors','2019-08-26 12:24:52','2019-08-26 12:24:52'),(20436,20433,'Other Baby Safety & Health','2019-08-26 12:24:52','2019-08-26 12:24:52'),(28009,550,'Art Posters','2019-08-26 12:24:45','2019-08-26 12:24:45'),(28179,625,'Binoculars & Telescopes','2019-08-26 12:24:47','2019-08-26 12:24:47'),(29223,267,'Antiquarian & Collectible','2019-08-26 12:24:46','2019-08-26 12:24:46'),(29792,267,'Audiobooks','2019-08-26 12:24:46','2019-08-26 12:24:46'),(29967,15200,'Battery Grips','2019-08-26 12:24:51','2019-08-26 12:24:51'),(29994,15200,'Accessory Bundles','2019-08-26 12:24:51','2019-08-26 12:24:51'),(36802,42892,'Other Automation Equipment','2019-08-26 12:24:55','2019-08-26 12:24:55'),(37903,20081,'Antiquities','2019-08-26 12:24:45','2019-08-26 12:24:45'),(37905,37903,'Egyptian','2019-08-26 12:24:55','2019-08-26 12:24:55'),(37906,37903,'Greek','2019-08-26 12:24:55','2019-08-26 12:24:55'),(37907,37903,'Roman','2019-08-26 12:24:55','2019-08-26 12:24:55'),(37908,37903,'The Americas','2019-08-26 12:24:55','2019-08-26 12:24:55'),(37909,4707,'Ceiling Tins','2019-08-26 12:24:50','2019-08-26 12:24:50'),(37910,4707,'Doors','2019-08-26 12:24:50','2019-08-26 12:24:50'),(37911,4707,'Hardware','2019-08-26 12:24:50','2019-08-26 12:24:50'),(37917,4707,'Tiles','2019-08-26 12:24:50','2019-08-26 12:24:50'),(37918,4707,'Weathervanes & Lightning Rods','2019-08-26 12:24:50','2019-08-26 12:24:50'),(37919,20082,'China','2019-08-26 12:24:51','2019-08-26 12:24:51'),(37934,20082,'Japan','2019-08-26 12:24:51','2019-08-26 12:24:51'),(42892,12576,'Automation, Motors & Drives','2019-08-26 12:24:46','2019-08-26 12:24:46'),(43440,15200,'Camera & Camcorder Lights','2019-08-26 12:24:51','2019-08-26 12:24:51'),(43448,15200,'Memory Card Readers & Adapters','2019-08-26 12:24:51','2019-08-26 12:24:51'),(45013,11748,'Wholesale Lots','2019-08-26 12:24:50','2019-08-26 12:24:50'),(45110,267,'Accessories','2019-08-26 12:24:46','2019-08-26 12:24:46'),(45111,45110,'Address Books','2019-08-26 12:24:55','2019-08-26 12:24:55'),(45112,45110,'Blank Diaries & Journals','2019-08-26 12:24:56','2019-08-26 12:24:56'),(45113,45110,'Book Covers','2019-08-26 12:24:56','2019-08-26 12:24:56'),(45114,45110,'Bookmarks','2019-08-26 12:24:56','2019-08-26 12:24:56'),(45115,45110,'Other Book Accessories','2019-08-26 12:24:56','2019-08-26 12:24:56'),(45452,20394,'Health & Grooming','2019-08-26 12:24:52','2019-08-26 12:24:52'),(45453,20394,'Towels & Washcloths','2019-08-26 12:24:52','2019-08-26 12:24:52'),(45454,20394,'Other Baby Bathing & Grooming','2019-08-26 12:24:52','2019-08-26 12:24:52'),(46526,11748,'Livestock Supplies','2019-08-26 12:24:50','2019-08-26 12:24:50'),(48831,45110,'Book Plates','2019-08-26 12:24:56','2019-08-26 12:24:56'),(50503,15200,'Memory Card Cases','2019-08-26 12:24:51','2019-08-26 12:24:51'),(50506,15200,'Underwater Cases & Housings','2019-08-26 12:24:51','2019-08-26 12:24:51'),(50508,15200,'LCD Hoods','2019-08-26 12:24:51','2019-08-26 12:24:51'),(50924,42892,'Industrial Robotic Arms','2019-08-26 12:24:55','2019-08-26 12:24:55'),(57516,42892,'Control Systems & PLCs','2019-08-26 12:24:55','2019-08-26 12:24:55'),(60209,20082,'India','2019-08-26 12:24:51','2019-08-26 12:24:51'),(61787,11748,'Forestry Equipment & Supplies','2019-08-26 12:24:50','2019-08-26 12:24:50'),(63516,4707,'Chandeliers, Sconces & Lighting Fixtures','2019-08-26 12:24:50','2019-08-26 12:24:50'),(63517,4707,'Finials','2019-08-26 12:24:50','2019-08-26 12:24:50'),(63518,4707,'Fireplaces, Mantels & Fireplace Accessories','2019-08-26 12:24:50','2019-08-26 12:24:50'),(63519,4707,'Signs & Plaques','2019-08-26 12:24:50','2019-08-26 12:24:50'),(63520,4707,'Windows, Shutters & Sash Locks','2019-08-26 12:24:50','2019-08-26 12:24:50'),(64343,15200,'Straps & Hand Grips','2019-08-26 12:24:51','2019-08-26 12:24:51'),(64345,15200,'Remotes & Shutter Releases','2019-08-26 12:24:51','2019-08-26 12:24:51'),(66834,37903,'Neolithic & Paleolithic','2019-08-26 12:24:55','2019-08-26 12:24:55'),(67339,15200,'Camcorder Tapes & Discs','2019-08-26 12:24:51','2019-08-26 12:24:51'),(73464,37903,'Other Antiquities','2019-08-26 12:24:55','2019-08-26 12:24:55'),(73470,20433,'Shopping Cart Covers','2019-08-26 12:24:52','2019-08-26 12:24:52'),(74922,28179,'Telescope Parts & Accessories','2019-08-26 12:24:53','2019-08-26 12:24:53'),(74927,28179,'Telescopes','2019-08-26 12:24:53','2019-08-26 12:24:53'),(78186,42892,'Drives & Starters','2019-08-26 12:24:55','2019-08-26 12:24:55'),(79947,20082,'Tibet','2019-08-26 12:24:51','2019-08-26 12:24:51'),(82563,20394,'Shampoos & Soaps','2019-08-26 12:24:52','2019-08-26 12:24:52'),(83857,15200,'Microphones','2019-08-26 12:24:51','2019-08-26 12:24:51'),(83880,28179,'Binoculars & Monoculars','2019-08-26 12:24:53','2019-08-26 12:24:53'),(91101,37903,'Near Eastern','2019-08-26 12:24:55','2019-08-26 12:24:55'),(100221,20394,'Bathing Accessories','2019-08-26 12:24:52','2019-08-26 12:24:52'),(100223,2984,'Baby Gear','2019-08-26 12:24:46','2019-08-26 12:24:46'),(100224,100223,'Other Baby Gear','2019-08-26 12:24:56','2019-08-26 12:24:56'),(107894,15200,'Cases, Bags & Covers','2019-08-26 12:24:51','2019-08-26 12:24:51'),(109471,12576,'Adhesives, Sealants & Tapes','2019-08-26 12:24:46','2019-08-26 12:24:46'),(109475,109471,'Adhesive Tapes','2019-08-26 12:24:56','2019-08-26 12:24:56'),(112084,4707,'Stair & Carpet Rods','2019-08-26 12:24:50','2019-08-26 12:24:50'),(113814,20394,'Bath Tubs','2019-08-26 12:24:52','2019-08-26 12:24:52'),(116556,20082,'Middle East','2019-08-26 12:24:51','2019-08-26 12:24:51'),(117016,20394,'Baby Scales','2019-08-26 12:24:52','2019-08-26 12:24:52'),(117026,20433,'Baby Thermometers','2019-08-26 12:24:52','2019-08-26 12:24:52'),(117029,20433,'Safety Gates','2019-08-26 12:24:52','2019-08-26 12:24:52'),(117032,100223,'Baby Jumping Exercisers','2019-08-26 12:24:56','2019-08-26 12:24:56'),(117033,100223,'Play Shades & Tents','2019-08-26 12:24:56','2019-08-26 12:24:56'),(117034,100223,'Bouncers & Vibrating Chairs','2019-08-26 12:24:56','2019-08-26 12:24:56'),(120869,45110,'Book Lights','2019-08-26 12:24:56','2019-08-26 12:24:56'),(134282,100223,'Walkers','2019-08-26 12:24:56','2019-08-26 12:24:56'),(134756,20394,'Gift Sets','2019-08-26 12:24:52','2019-08-26 12:24:52'),(134761,20433,'Toddler Safety Harnesses','2019-08-26 12:24:52','2019-08-26 12:24:52'),(134762,20433,'Car Window Signs & Decals','2019-08-26 12:24:52','2019-08-26 12:24:52'),(151721,4707,'Stained Glass Windows','2019-08-26 12:24:50','2019-08-26 12:24:50'),(155707,15200,'Cables & Adapters','2019-08-26 12:24:51','2019-08-26 12:24:51'),(159685,11748,'GPS & Guidance Equipment','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162024,20394,'Bath Tub Seats & Rings','2019-08-26 12:24:52','2019-08-26 12:24:52'),(162026,45110,'Bookends','2019-08-26 12:24:56','2019-08-26 12:24:56'),(162028,45110,'Book Stands, Holders','2019-08-26 12:24:56','2019-08-26 12:24:56'),(162044,28179,'Other Binoculars & Telescopes','2019-08-26 12:24:53','2019-08-26 12:24:53'),(162045,15200,'Batteries','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162046,15200,'Chargers & Cradles','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162053,15200,'Cleaning Equipment & Kits','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162183,20433,'Bed Rails','2019-08-26 12:24:52','2019-08-26 12:24:52'),(162480,15200,'Other Camera & Photo Accs','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162485,28179,'Binocular Cases & Accessories','2019-08-26 12:24:53','2019-08-26 12:24:53'),(162916,37903,'Far Eastern','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162917,37903,'Holy Land','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162918,37903,'Islamic','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162919,37903,'South Italian','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162920,37903,'Viking','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162922,37903,'Byzantine','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162923,37903,'Celtic','2019-08-26 12:24:55','2019-08-26 12:24:55'),(162925,4707,'Balusters','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162926,4707,'Barn Doors & Barn Door Hardware','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162927,4707,'Beams','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162928,4707,'Columns & Posts','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162929,4707,'Corbels','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162936,4707,'Pediments','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162937,4707,'Reproductions','2019-08-26 12:24:50','2019-08-26 12:24:50'),(162938,20082,'Burma','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162979,20082,'Korea','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162988,20082,'Unknown','2019-08-26 12:24:51','2019-08-26 12:24:51'),(162989,20082,'Mongolia','2019-08-26 12:24:51','2019-08-26 12:24:51'),(164808,20082,'Southeast Asia','2019-08-26 12:24:51','2019-08-26 12:24:51'),(167928,15200,'Screen Protectors','2019-08-26 12:24:51','2019-08-26 12:24:51'),(167930,15200,'Viewfinders & Eyecups','2019-08-26 12:24:51','2019-08-26 12:24:51'),(167948,4707,'Plumbing & Fixtures','2019-08-26 12:24:50','2019-08-26 12:24:50'),(171170,4707,'Price Guides & Publications','2019-08-26 12:24:50','2019-08-26 12:24:50'),(181730,42892,'Electric Motors','2019-08-26 12:24:55','2019-08-26 12:24:55'),(181736,42892,'Rotary & Linear Motion','2019-08-26 12:24:55','2019-08-26 12:24:55'),(181748,42892,'Mechanical Power Transmission','2019-08-26 12:24:55','2019-08-26 12:24:55'),(182075,15200,'Photo Albums & Storage','2019-08-26 12:24:51','2019-08-26 12:24:51'),(183746,109471,'Glues, Epoxies & Cements','2019-08-26 12:24:56','2019-08-26 12:24:56'),(183780,109471,'Adhesive Guns & Dispensers','2019-08-26 12:24:56','2019-08-26 12:24:56'),(184304,109471,'Caulks, Sealants & Removers','2019-08-26 12:24:56','2019-08-26 12:24:56'),(184339,20433,'Baby Proofing','2019-08-26 12:24:52','2019-08-26 12:24:52'),(184343,20433,'Hearing Protection Earmuffs','2019-08-26 12:24:52','2019-08-26 12:24:52'),(184344,177,'PC Laptops & Netbooks','2019-08-26 12:25:01','2019-08-26 12:25:01');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `region_id` bigint(20) DEFAULT NULL,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cities_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_vip` tinyint(1) NOT NULL DEFAULT 0,
  `is_company` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contact_datas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_datas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) DEFAULT NULL,
  `country_id` bigint(20) DEFAULT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contact_datas` WRITE;
/*!40000 ALTER TABLE `contact_datas` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_datas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `countries_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Sao Tome and Principe','st','2019-08-26 13:02:39','2019-08-26 13:02:39'),(2,'Romania','ro','2019-08-26 13:02:39','2019-08-26 13:02:39'),(3,'Czech Republic','cz','2019-08-26 13:02:40','2019-08-26 13:02:40'),(4,'France','fr','2019-08-26 13:02:41','2019-08-26 13:02:41'),(5,'Bermuda','bm','2019-08-26 13:02:41','2019-08-26 13:02:41'),(6,'Cape Verde','cv','2019-08-26 13:03:16','2019-08-26 13:03:16'),(7,'Mayotte','yt','2019-08-26 13:03:17','2019-08-26 13:03:17'),(8,'Fiji','fj','2019-08-26 13:03:17','2019-08-26 13:03:17'),(9,'Antigua and Barbuda','ag','2019-08-26 13:03:17','2019-08-26 13:03:17'),(10,'Saint Vincent and the Grenadines','vc','2019-08-26 13:03:18','2019-08-26 13:03:18');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'US Dollar','USD','2019-08-26 12:25:01','2019-08-26 12:25:01');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currency_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `currency_id` bigint(20) DEFAULT NULL,
  `rate` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currency_rates` WRITE;
/*!40000 ALTER TABLE `currency_rates` DISABLE KEYS */;
INSERT INTO `currency_rates` VALUES (1,1,17.45,'2019-08-26 12:25:01','2019-08-26 12:25:01');
/*!40000 ALTER TABLE `currency_rates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emails` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contact_data_id` bigint(20) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emails_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
INSERT INTO `emails` VALUES (1,NULL,'111admin@site.com',1,'2019-08-26 12:35:40','2019-08-26 12:35:40'),(2,NULL,'lehner.alexandrea@gmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(3,NULL,'marlin.shanahan@bartell.info',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(4,NULL,'ldenesik@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(5,NULL,'stokes.saige@mayer.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(6,NULL,'nikolaus.bonnie@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(7,NULL,'alexandria.schultz@fritsch.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(8,NULL,'lynch.chadrick@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(9,NULL,'kariane.gutkowski@kerluke.net',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(10,NULL,'asha57@gmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(11,NULL,'bemard@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(12,NULL,'hauck.arianna@beer.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(13,NULL,'llewellyn.mante@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(14,NULL,'psporer@hotmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(15,NULL,'jbayer@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(16,NULL,'ustrosin@gmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(17,NULL,'lakin.abel@bogan.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(18,NULL,'lula.crooks@bechtelar.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(19,NULL,'hermann.destinee@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(20,NULL,'talia85@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(21,NULL,'sheldon92@wisoky.org',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(22,NULL,'roberts.danial@johnson.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(23,NULL,'ustoltenberg@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(24,NULL,'myra22@considine.org',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(25,NULL,'rau.tierra@schimmel.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(26,NULL,'oschiller@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(27,NULL,'larson.carol@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(28,NULL,'asenger@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(29,NULL,'schultz.hazle@schulist.biz',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(30,NULL,'peter12@gmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(31,NULL,'farrell.jerry@gmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(32,NULL,'wgoldner@hotmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(33,NULL,'allie.green@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(34,NULL,'dlittel@jenkins.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(35,NULL,'vivienne78@hills.org',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(36,NULL,'hudson.freda@crist.net',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(37,NULL,'corwin.billy@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(38,NULL,'roberts.adam@rempel.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(39,NULL,'jasper.ward@miller.biz',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(40,NULL,'bosco.braxton@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(41,NULL,'qoconnell@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(42,NULL,'kameron59@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(43,NULL,'douglas.cleve@gmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(44,NULL,'nrau@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(45,NULL,'daniel.aletha@hotmail.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(46,NULL,'sarah50@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(47,NULL,'jordyn20@wolf.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(48,NULL,'van73@mills.biz',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(49,NULL,'rolfson.eric@hotmail.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(50,NULL,'cmohr@yahoo.com',0,'2019-08-26 12:36:21','2019-08-26 12:36:21'),(51,NULL,'ferne.fay@yahoo.com',1,'2019-08-26 12:36:21','2019-08-26 12:36:21');
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (143,'2019_08_07_154835_create_products_table',1),(144,'2019_08_07_161021_create_currencies_table',1),(145,'2019_08_11_110909_create_currency_rates_table',1),(146,'2019_08_11_123928_create_prices_table',1),(147,'2019_08_12_153243_create_clients_table',1),(148,'2019_08_12_153723_create_contact_datas_table',1),(149,'2019_08_12_154340_create_countries_table',1),(150,'2019_08_12_154938_create_cities_table',1),(151,'2019_08_12_155521_create_phones_table',1),(152,'2019_08_13_203748_create_emails_table',1),(153,'2019_08_16_053423_create_regions_table',1),(154,'2019_08_16_055419_create_socials_table',1),(155,'2019_08_16_055438_create_social_platforms_table',1),(156,'2019_08_19_154923_create_tags_table',1),(157,'2019_08_19_155049_create_categories_table',1),(158,'2019_08_25_153817_create_carts_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contact_data_id` bigint(20) DEFAULT NULL,
  `number` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_mobile` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `phones` WRITE;
/*!40000 ALTER TABLE `phones` DISABLE KEYS */;
/*!40000 ALTER TABLE `phones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `currency_id` bigint(20) DEFAULT NULL,
  `priceable_id` bigint(20) DEFAULT NULL,
  `priceable_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` decimal(11,2) NOT NULL,
  `discount` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prices` WRITE;
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;
INSERT INTO `prices` VALUES (1,1,1,'App\\Cart',120.00,0.00,'2019-08-26 12:16:46','2019-08-26 12:16:46'),(2,1,2,'App\\Cart',185.00,0.00,'2019-08-26 12:16:46','2019-08-26 12:16:46'),(3,1,3,'App\\Cart',225.00,0.00,'2019-08-26 12:16:46','2019-08-26 12:16:46'),(4,1,2,'App\\Product',373.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(5,1,3,'App\\Product',309.95,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(6,1,4,'App\\Product',289.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(7,1,5,'App\\Product',299.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(8,1,6,'App\\Product',489.49,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(9,1,7,'App\\Product',175.00,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(10,1,8,'App\\Product',169.00,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(11,1,9,'App\\Product',159.00,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(12,1,10,'App\\Product',129.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(13,1,11,'App\\Product',581.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(14,1,12,'App\\Product',239.00,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(15,1,13,'App\\Product',400.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(16,1,14,'App\\Product',464.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(17,1,15,'App\\Product',328.00,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(18,1,16,'App\\Product',522.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(19,1,17,'App\\Product',219.80,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(20,1,18,'App\\Product',93.71,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(21,1,19,'App\\Product',400.00,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(22,1,20,'App\\Product',453.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01'),(23,1,21,'App\\Product',179.99,0.00,'2019-08-26 12:25:01','2019-08-26 12:25:01');
/*!40000 ALTER TABLE `prices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'iPhone 9',NULL,NULL,'2019-08-26 12:16:46','2019-08-26 12:16:46'),(2,'ASUS VivoBook FHD 15.6\" Laptop, Up to 16GB RAM, 512GB SSD, A12, USB-C, Win 10','','https://thumbs1.ebaystatic.com/pict/04040_0.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(3,'NEW! ASUS 15.6” Full-HD AMD A12 3.70GHz 4GB 128GB SSD WebCam Lightweight Laptop','FINGERPRINT READER ~ 1920x1080 FHD ~ RJ45/HDMI/WiFi/BT','https://thumbs3.ebaystatic.com/m/mQPCy3IAjfj-IhPxybIDE0A/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(4,'Asus Chromebook Flip C302C 12.5\" 2 in 1 Touch 8GB RAM 32GB SSD Chrome OS Wty ','','https://thumbs4.ebaystatic.com/m/m1-_VFyIgrt2hMzqawEZxyw/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(5,'ASUS 15.6\" HD Laptop Quad Core 3.6GHZ 128GB SSD 8GB RAM Radeon Windows 10','','https://thumbs4.ebaystatic.com/m/m4fikYPmn8MfPohm_24BZZA/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(6,'New Asus VivoBook F412DA-IB51 14\'\' FHD Laptop AMD Ryzen 5 3500U 8GB 256GB SSD','','https://thumbs2.ebaystatic.com/m/mWNS6HUoCdcwL1lCrbj6tHA/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(7,'Asus Chromebook 14.0 HD Silver','','https://thumbs3.ebaystatic.com/m/mzFslGWIu0H7lttCV9QhDEw/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(8,'ASUS 15” HD Gaming Laptop Intel Core i3-2350M 2.30GHz 12GB RAM 320GB HDD Win10','','https://thumbs1.ebaystatic.com/m/mMXFE1NL0FNL73utterLyfw/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(9,'ASUS Q301LA 13.3\" i5 Touchscreen Laptop','','https://thumbs4.ebaystatic.com/m/m_x9-IcNwyrZf0SSUHikoXg/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(10,'Asus T102HA-C4-GR 10.1\" Touchscreen Laptop Intel X5-Z8350 1.44GHz 4GB 64GB W10','','https://thumbs4.ebaystatic.com/m/mpjCW_rPgdRYvlGqbKVdUlg/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(11,'ASUS VivoBook FHD 15.6\" Laptop, Up to 16GB RAM, 512GB SSD, A12, USB-C, Win 10','','https://thumbs2.ebaystatic.com/pict/2644362125094040_1.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(12,'ASUS X441BA 14 inch HD Laptop 7th Gen AMD A6-9225 4GB RAM 500GB HDD Windows 10','AMD Radeon R4, WiFi, Bluetooth, 1 Year Warranty.','https://thumbs3.ebaystatic.com/m/mtI2lhhZJ8kLB-zox0XmW9A/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(13,'ASUS VivoBook FHD 15.6\" Laptop, Up to 16GB RAM, 512GB SSD, A12, USB-C, Win 10','','https://thumbs2.ebaystatic.com/pict/2644362125094040_1.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(14,'ASUS VivoBook FHD 15.6\" Laptop, Up to 16GB RAM, 512GB SSD, A12, USB-C, Win 10','','https://thumbs2.ebaystatic.com/pict/2644362125094040_1.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(15,'ASUS ZENBOOK UX303UB 13.3\" 512GB SSD, Intel i7, 12GB RAM, 3200x1800 QHD+, 940M','','https://thumbs4.ebaystatic.com/m/mKS9rbMbKgFMJ1vOXtnIe1w/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(16,'ASUS VivoBook FHD 15.6\" Laptop, Up to 16GB RAM, 512GB SSD, A12, USB-C, Win 10','','https://thumbs2.ebaystatic.com/pict/2644362125094040_1.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(17,'2019 Newest ASUS 14\" Laptop AMD A6 Dual-Core 2.6GHz, up to 12GB RAM & 1TB SSD','Choose: 4GB|8GB|12GB RAM, 256GB|512GB|1TB SSD,Radeon R4','https://thumbs1.ebaystatic.com/pict/04040_0.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(18,'ASUS Ultrabook S56C, Intel Core i3, 4GB RAM, Windows 7, SSD 700 GB + OS HD 25 GB','','https://thumbs2.ebaystatic.com/m/mqZixIASbLbkmD3Kmzxmuzg/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(19,'ASUS ROG Gaming Smartphone - Used ','','https://thumbs2.ebaystatic.com/m/mbPMJl0Z60UIUbcu5Xc1lZw/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(20,'ASUS VivoBook FHD 15.6\" Laptop, Up to 16GB RAM, 512GB SSD, A12, USB-C, Win 10','','https://thumbs2.ebaystatic.com/pict/2644362125094040_1.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01'),(21,'Asus LAPTOP Transformer Book T100T PC 10.1\" TABLET 2 in 1 Windows 10 64GB SSD','','https://thumbs4.ebaystatic.com/m/mh_QI2DFVo47QN8TldnGs9A/140.jpg','2019-08-26 12:25:01','2019-08-26 12:25:01');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` bigint(20) DEFAULT NULL,
  `region` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` VALUES (1,1,'Principe','2019-08-26 13:02:39','2019-08-26 13:02:39'),(2,1,'Sao Tome','2019-08-26 13:02:39','2019-08-26 13:02:39'),(3,2,'Arad','2019-08-26 13:02:39','2019-08-26 13:02:39'),(4,2,'Bihor','2019-08-26 13:02:39','2019-08-26 13:02:39'),(5,2,'Bucuresti','2019-08-26 13:02:39','2019-08-26 13:02:39'),(6,2,'Constanta','2019-08-26 13:02:39','2019-08-26 13:02:39'),(7,2,'Covasna','2019-08-26 13:02:39','2019-08-26 13:02:39'),(8,2,'Dolj','2019-08-26 13:02:39','2019-08-26 13:02:39'),(9,2,'Giurgiu','2019-08-26 13:02:39','2019-08-26 13:02:39'),(10,2,'Gorj','2019-08-26 13:02:39','2019-08-26 13:02:39'),(11,2,'Harghita','2019-08-26 13:02:39','2019-08-26 13:02:39'),(12,2,'Hunedoara','2019-08-26 13:02:39','2019-08-26 13:02:39'),(13,2,'Ilfov','2019-08-26 13:02:39','2019-08-26 13:02:39'),(14,2,'Judetul Alba','2019-08-26 13:02:39','2019-08-26 13:02:39'),(15,2,'Judetul Arges','2019-08-26 13:02:39','2019-08-26 13:02:39'),(16,2,'Judetul Bacau','2019-08-26 13:02:39','2019-08-26 13:02:39'),(17,2,'Judetul Bistrita-Nasaud','2019-08-26 13:02:39','2019-08-26 13:02:39'),(18,2,'Judetul Botosani','2019-08-26 13:02:39','2019-08-26 13:02:39'),(19,2,'Judetul Braila','2019-08-26 13:02:39','2019-08-26 13:02:39'),(20,2,'Judetul Brasov','2019-08-26 13:02:39','2019-08-26 13:02:39'),(21,2,'Judetul Buzau','2019-08-26 13:02:39','2019-08-26 13:02:39'),(22,2,'Judetul Calarasi','2019-08-26 13:02:39','2019-08-26 13:02:39'),(23,2,'Judetul Caras-Severin','2019-08-26 13:02:39','2019-08-26 13:02:39'),(24,2,'Judetul Cluj','2019-08-26 13:02:39','2019-08-26 13:02:39'),(25,2,'Judetul Dambovita','2019-08-26 13:02:39','2019-08-26 13:02:39'),(26,2,'Judetul Galati','2019-08-26 13:02:39','2019-08-26 13:02:39'),(27,2,'Judetul Ialomita','2019-08-26 13:02:39','2019-08-26 13:02:39'),(28,2,'Judetul Iasi','2019-08-26 13:02:39','2019-08-26 13:02:39'),(29,2,'Judetul Maramures','2019-08-26 13:02:39','2019-08-26 13:02:39'),(30,2,'Judetul Mehedinti','2019-08-26 13:02:39','2019-08-26 13:02:39'),(31,2,'Judetul Mures','2019-08-26 13:02:39','2019-08-26 13:02:39'),(32,2,'Judetul Neamt','2019-08-26 13:02:39','2019-08-26 13:02:39'),(33,2,'Judetul Salaj','2019-08-26 13:02:39','2019-08-26 13:02:39'),(34,2,'Judetul Sibiu','2019-08-26 13:02:39','2019-08-26 13:02:39'),(35,2,'Judetul Timis','2019-08-26 13:02:39','2019-08-26 13:02:39'),(36,2,'Judetul Valcea','2019-08-26 13:02:39','2019-08-26 13:02:39'),(37,2,'Olt','2019-08-26 13:02:39','2019-08-26 13:02:39'),(38,2,'Prahova','2019-08-26 13:02:39','2019-08-26 13:02:39'),(39,2,'Satu Mare','2019-08-26 13:02:39','2019-08-26 13:02:39'),(40,2,'Suceava','2019-08-26 13:02:39','2019-08-26 13:02:39'),(41,2,'Teleorman','2019-08-26 13:02:39','2019-08-26 13:02:39'),(42,2,'Tulcea','2019-08-26 13:02:39','2019-08-26 13:02:39'),(43,2,'Vaslui','2019-08-26 13:02:39','2019-08-26 13:02:39'),(44,2,'Vrancea','2019-08-26 13:02:39','2019-08-26 13:02:39'),(45,3,'Hlavni mesto Praha','2019-08-26 13:02:40','2019-08-26 13:02:40'),(46,3,'Jihocesky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(47,3,'Jihomoravsky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(48,3,'Karlovarsky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(49,3,'Kraj Vysocina','2019-08-26 13:02:40','2019-08-26 13:02:40'),(50,3,'Kralovehradecky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(51,3,'Liberecky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(52,3,'Moravskoslezsky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(53,3,'Olomoucky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(54,3,'Pardubicky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(55,3,'Plzensky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(56,3,'Stredocesky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(57,3,'Ustecky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(58,3,'Zlinsky kraj','2019-08-26 13:02:40','2019-08-26 13:02:40'),(59,4,'Auvergne-Rhone-Alpes','2019-08-26 13:02:41','2019-08-26 13:02:41'),(60,4,'Bourgogne-Franche-Comte','2019-08-26 13:02:41','2019-08-26 13:02:41'),(61,4,'Bretagne','2019-08-26 13:02:41','2019-08-26 13:02:41'),(62,4,'Centre-Val de Loire','2019-08-26 13:02:41','2019-08-26 13:02:41'),(63,4,'Corse','2019-08-26 13:02:41','2019-08-26 13:02:41'),(64,4,'Grand-Est','2019-08-26 13:02:41','2019-08-26 13:02:41'),(65,4,'Hauts-de-France','2019-08-26 13:02:41','2019-08-26 13:02:41'),(66,4,'Ile-de-France','2019-08-26 13:02:41','2019-08-26 13:02:41'),(67,4,'Normandy','2019-08-26 13:02:41','2019-08-26 13:02:41'),(68,4,'Nouvelle-Aquitaine','2019-08-26 13:02:41','2019-08-26 13:02:41'),(69,4,'Occitanie','2019-08-26 13:02:41','2019-08-26 13:02:41'),(70,4,'Pays de la Loire','2019-08-26 13:02:41','2019-08-26 13:02:41'),(71,4,'Provence-Alpes-Cote d\'Azur','2019-08-26 13:02:41','2019-08-26 13:02:41'),(72,5,'Devonshire Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(73,5,'Hamilton','2019-08-26 13:02:42','2019-08-26 13:02:42'),(74,5,'Paget Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(75,5,'Pembroke Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(76,5,'Saint George','2019-08-26 13:02:42','2019-08-26 13:02:42'),(77,5,'Saint George\'s Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(78,5,'Sandys Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(79,5,'Smith\'s Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(80,5,'Southampton Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(81,5,'Warwick Parish','2019-08-26 13:02:42','2019-08-26 13:02:42'),(82,6,'Concelho da Boa Vista','2019-08-26 13:03:17','2019-08-26 13:03:17'),(83,6,'Concelho da Brava','2019-08-26 13:03:17','2019-08-26 13:03:17'),(84,6,'Concelho da Praia','2019-08-26 13:03:17','2019-08-26 13:03:17'),(85,6,'Concelho da Ribeira Brava','2019-08-26 13:03:17','2019-08-26 13:03:17'),(86,6,'Concelho da Ribeira Grande','2019-08-26 13:03:17','2019-08-26 13:03:17'),(87,6,'Concelho de Ribeira Grande de Santiago','2019-08-26 13:03:17','2019-08-26 13:03:17'),(88,6,'Concelho de Santa Catarina','2019-08-26 13:03:17','2019-08-26 13:03:17'),(89,6,'Concelho de Santa Catarina do Fogo','2019-08-26 13:03:17','2019-08-26 13:03:17'),(90,6,'Concelho de Santa Cruz','2019-08-26 13:03:17','2019-08-26 13:03:17'),(91,6,'Concelho de Sao Domingos','2019-08-26 13:03:17','2019-08-26 13:03:17'),(92,6,'Concelho de Sao Miguel','2019-08-26 13:03:17','2019-08-26 13:03:17'),(93,6,'Concelho de Sao Salvador do Mundo','2019-08-26 13:03:17','2019-08-26 13:03:17'),(94,6,'Concelho de Sao Vicente','2019-08-26 13:03:17','2019-08-26 13:03:17'),(95,6,'Concelho do Maio','2019-08-26 13:03:17','2019-08-26 13:03:17'),(96,6,'Concelho do Paul','2019-08-26 13:03:17','2019-08-26 13:03:17'),(97,6,'Concelho do Porto Novo','2019-08-26 13:03:17','2019-08-26 13:03:17'),(98,6,'Concelho do Sao Filipe','2019-08-26 13:03:17','2019-08-26 13:03:17'),(99,6,'Concelho do Tarrafal','2019-08-26 13:03:17','2019-08-26 13:03:17'),(100,6,'Concelho do Tarrafal de Sao Nicolau','2019-08-26 13:03:17','2019-08-26 13:03:17'),(101,6,'Concelho dos Mosteiros','2019-08-26 13:03:17','2019-08-26 13:03:17'),(102,6,'Sal Municipality','2019-08-26 13:03:17','2019-08-26 13:03:17'),(103,6,'Sao Lourenco dos Orgaos','2019-08-26 13:03:17','2019-08-26 13:03:17'),(104,7,'Acoua','2019-08-26 13:03:17','2019-08-26 13:03:17'),(105,7,'Bandraboua','2019-08-26 13:03:17','2019-08-26 13:03:17'),(106,7,'Bandrele','2019-08-26 13:03:17','2019-08-26 13:03:17'),(107,7,'Boueni','2019-08-26 13:03:17','2019-08-26 13:03:17'),(108,7,'Chiconi','2019-08-26 13:03:17','2019-08-26 13:03:17'),(109,7,'Chirongui','2019-08-26 13:03:17','2019-08-26 13:03:17'),(110,7,'Dembeni','2019-08-26 13:03:17','2019-08-26 13:03:17'),(111,7,'Dzaoudzi','2019-08-26 13:03:17','2019-08-26 13:03:17'),(112,7,'Kani-Keli','2019-08-26 13:03:17','2019-08-26 13:03:17'),(113,7,'Koungou','2019-08-26 13:03:17','2019-08-26 13:03:17'),(114,7,'M\'Tsangamouji','2019-08-26 13:03:17','2019-08-26 13:03:17'),(115,7,'Mamoudzou','2019-08-26 13:03:17','2019-08-26 13:03:17'),(116,7,'Mtsamboro','2019-08-26 13:03:17','2019-08-26 13:03:17'),(117,7,'Ouangani','2019-08-26 13:03:17','2019-08-26 13:03:17'),(118,7,'Pamandzi','2019-08-26 13:03:17','2019-08-26 13:03:17'),(119,7,'Sada','2019-08-26 13:03:17','2019-08-26 13:03:17'),(120,7,'Tsingoni','2019-08-26 13:03:17','2019-08-26 13:03:17'),(121,8,'Central Division','2019-08-26 13:03:17','2019-08-26 13:03:17'),(122,8,'Eastern Division','2019-08-26 13:03:17','2019-08-26 13:03:17'),(123,8,'Northern Division','2019-08-26 13:03:17','2019-08-26 13:03:17'),(124,8,'Rotuma','2019-08-26 13:03:17','2019-08-26 13:03:17'),(125,8,'Western Division','2019-08-26 13:03:17','2019-08-26 13:03:17'),(126,9,'Barbuda','2019-08-26 13:03:18','2019-08-26 13:03:18'),(127,9,'Parish of Saint George','2019-08-26 13:03:18','2019-08-26 13:03:18'),(128,9,'Parish of Saint John','2019-08-26 13:03:18','2019-08-26 13:03:18'),(129,9,'Parish of Saint Mary','2019-08-26 13:03:18','2019-08-26 13:03:18'),(130,9,'Parish of Saint Paul','2019-08-26 13:03:18','2019-08-26 13:03:18'),(131,9,'Parish of Saint Peter','2019-08-26 13:03:18','2019-08-26 13:03:18'),(132,9,'Parish of Saint Philip','2019-08-26 13:03:18','2019-08-26 13:03:18'),(133,9,'Redonda','2019-08-26 13:03:18','2019-08-26 13:03:18'),(134,10,'Grenadines','2019-08-26 13:03:18','2019-08-26 13:03:18'),(135,10,'Parish of Charlotte','2019-08-26 13:03:18','2019-08-26 13:03:18'),(136,10,'Parish of Saint Andrew','2019-08-26 13:03:18','2019-08-26 13:03:18'),(137,10,'Parish of Saint David','2019-08-26 13:03:18','2019-08-26 13:03:18'),(138,10,'Parish of Saint George','2019-08-26 13:03:18','2019-08-26 13:03:18'),(139,10,'Parish of Saint Patrick','2019-08-26 13:03:18','2019-08-26 13:03:18');
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `social_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_platforms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `social_platforms` WRITE;
/*!40000 ALTER TABLE `social_platforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_platforms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `socials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `socials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `social_platform_id` bigint(20) DEFAULT NULL,
  `contact_data_id` bigint(20) DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `socials` WRITE;
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

