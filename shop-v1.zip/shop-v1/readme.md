INSTALLATION:

1. git clone https://github.com/SergheiPogor/shop-v1-laravel.git
2. update file ".env"
3. composer update


https://www.techempower.com/benchmarks/#section=data-r18&hw=ph&test=json